package com.cg.ic.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.ic.util.DBConnection;

public class Insurance {
	public static void main(String[] args)  {
		try {
		Connection con=DBConnection.getConnection();
	
		PreparedStatement ps=con.prepareStatement("select username from user_role");
		
		ResultSet rs=ps.executeQuery();
		String  name=rs.getString(1);
		System.out.println(name);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
