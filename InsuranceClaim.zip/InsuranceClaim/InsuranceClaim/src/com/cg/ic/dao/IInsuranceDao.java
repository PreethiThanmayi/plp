package com.cg.ic.dao;

import java.sql.SQLException;

import com.cg.ic.bean.Policy;
import com.cg.ic.bean.UserRole;

public interface IInsuranceDao {

	String verifyUser(String name, String pass) throws SQLException, Exception;

	Policy getPolicyDetails(String name) throws Exception;

}
