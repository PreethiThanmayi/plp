package com.cg.ic.service;

import java.sql.SQLException;

import com.cg.ic.bean.Policy;
import com.cg.ic.bean.UserRole;
import com.cg.ic.dao.IInsuranceDao;
import com.cg.ic.dao.InsuranceDaoImpl;

public class InsuranceServiceImpl implements IInsuranceService {

	
	public String verifyUser(String name, String pass) throws SQLException, Exception {
	   
		IInsuranceDao dao=new InsuranceDaoImpl();
		return  dao.verifyUser(name,pass);
	}


	public Policy getPolicyDetails(String name) throws Exception {
		Policy policy=new Policy();
		IInsuranceDao dao=new InsuranceDaoImpl();
		System.out.println("3");
		 policy= dao.getPolicyDetails(name);
		System.out.println("4");
		return policy;
	}

}
